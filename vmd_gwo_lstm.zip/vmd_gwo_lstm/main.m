%% VMD-GWO-LSTM main.m
% Author：
% Date：

clc; %清空命令行
clear; %清空工作区
%% 数据导入与预处理（选用特定分解模态IMF作训练集与验证集）
data = readtable('波面统计.csv');
time_str = data{:, 'Time'};  % 如果时间列的名称是'Time'
Hs = data{:, 'Hs'};  % 如果浪高列的名称是'Hs'
time_str = data{:, 1}; % 读取第一列时间数据
Hs = data{:, 2}; % 读取第二列浪高数据

% 用户设置参数
k_value = 4; % 用户设置的k值
k_index = 3; % 用户设置k索引值，即选定用哪一条IMF
% VMD分解
numIMFs = k_value;
[HsIMFs, ~] = vmd(Hs, 'NumIMFs', numIMFs);
data = HsIMFs(:,k_index)

num=size(data,1); %获得序列长度。
numTrain=1200; %指定序列前numTrain个用于训练。
numValidation=num-numTrain; %指定验证序列规模。

% 序列的前numTrain个用于训练，其余用于验证神经网络
dataTrain = Hs(1:numTrain+1);    %定义训练集，夺取一个用于后续裁剪
dataValidation = Hs(numTrain+1:num);  %该数据是用来验证RMSE的

% 序列数据预处理：归一化
mu = mean(dataTrain);    %求均值 
sig = std(dataTrain);      %求均差 
dataTrainStandardized = (dataTrain - mu) / sig; 
for i=1:size(dataTrainStandardized,2)
    if dataTrainStandardized(i)>2
        dataTrainStandardized(i)=2;
    elseif dataTrainStandardized(i)<-2
        dataTrainStandardized(i)=-2; 
    end
end %强制处理离群值

% 输入的每个时间步，LSTM网络学习预测下一个时间步，这里交错一个时间步效果最好。
XTrain = dataTrainStandardized(1:end-1);  
YTrain = dataTrainStandardized(2:end);  

%% GWO-LSTM主程序
% 狼群数量
SearchAgents_no = 10;
% GWO最大迭代次数
Max_iter_GWO = 1; %需要与神经网络迭代次数区分开
% 变量维度，选择初始学习率、神经网络迭代次数、隐含层单元数、学习率削减区段与学习率削减因子五个参数以及MA窗口大小为寻优对象
% 学习率取值区间为0.005到0.050，步长0.005；神经网络迭代次数为150到500，步长1；
% 隐含层单元数为180到220，步长为1；
% 优化参数项LearnRateDropPeriod学习率削减区段与LearnRateDropFactor学习率削减因子，前者200至500步长1，后者0.05至0.8步长0.01；
dim = 6;
% 为rmse与对应超参数预分配存储空间
rmse=zeros(SearchAgents_no,1);
rmse_para=zeros(SearchAgents_no,dim);
% 上限
ub = [0.05 500 220 500 0.8 20];
% 下限
lb = [0.005 150 180 200 0.05 2];
% 步长
step = [0.005 1 1 1 0.01 1];
% 初始化
Alpha_pos = zeros(1, dim);
Alpha_score = inf;
Beta_pos = zeros(1, dim);
Beta_score = inf;
Delta_pos = zeros(1, dim);
Delta_score = inf;
% 初始化位置
numstep=(ub-lb)./step; %计算步数
Positions = round(rand(SearchAgents_no,1)*numstep).*step + repmat(lb, SearchAgents_no, 1);%生成位置
Convergence_curve = zeros(Max_iter_GWO,1);
Convergence_para = zeros(Max_iter_GWO,dim);
% 主循环
for l = 1 : Max_iter_GWO
    for i = 1:SearchAgents_no
        % 边界处理：越界赋值为中间值，赋边界值会导致全部收敛至边界值而寻优失效，注意这里逻辑数组的运用
        Flag4ub = Positions(i, :) >= ub;
        Flag4lb = Positions(i, :) <= lb;
        Positions(i, :) = (Positions(i, :) .* (~(Flag4ub + Flag4lb))) + (round(numstep.*rand(1,dim)).*step+lb) .* (Flag4ub + Flag4lb);      
        
        % 使用生成超参数建立LSTM神经网络，返回相应参数下的rmse与超参数；
        numFeatures = 1;   %特征为一维
        numResponses = 1;  %输出也是一维
        numHiddenUnits = Positions(i,3);   %创建LSTM回归网络，指定LSTM层的隐含单元个数
        layers = [ ...
             sequenceInputLayer(numFeatures)    %输入层
             lstmLayer(numHiddenUnits)  % lstm层，如果是构建多层的LSTM模型，可以修改。
             fullyConnectedLayer(numResponses)    %为全连接层,是输出的维数。
             regressionLayer];      %其计算回归问题的半均方误差模块 。即说明这不是在进行分类问题。
        %指定训练选项，求解器设置为adam。
        %梯度阈值设置为 1。指定初始学习率后，在LearnRateDropPeriod轮训练后通过乘以因子LearnRateDropFactor来降低学习率。
        options = trainingOptions('adam', ...
          'MaxEpochs',Positions(i,2), ...
          'GradientThreshold',1, ...
          'InitialLearnRate',Positions(i,1), ...      
          'LearnRateSchedule','piecewise', ...%每当经过一定数量的时期时，学习率就会乘以一个系数。
          'LearnRateDropPeriod',Positions(i,4), ...      %乘法之间的纪元数由“ LearnRateDropPeriod”控制。可调
          'LearnRateDropFactor',Positions(i,5), ...      %乘法因子由参“ LearnRateDropFactor”控制，可调
          'Verbose',0,  ...  %如果将其设置为true，则有关训练进度的信息将被打印到命令窗口中。默认值为true。
          'Plots','none');    %构建曲线图 将'training-progress'替换为none即关闭训练弹窗
         net = trainNetwork(XTrain',YTrain',layers,options);
        % 依据给出参数初始化网络状态
         [net,YPred] = predictAndUpdateState(net,XTrain');  %将新的XTrain数据用在网络上进行初始化网络状态
         % [net,YPred] = predictAndUpdateState(net,YTrain(end));  %用训练的最后一步来进行预测第一个预测值，给定一个初始值。这是用预测值更新网络状态特有的。
        % 进行用于验证神经网络的数据预测（用预测值更新网络状态）
            for j = 2:num-numTrain+numValidation  %从第二步开始，这里进行验证+预测值次数的单步预测。
            [net,YPred(:,j)] = predictAndUpdateState(net,YPred(:,j-1),'ExecutionEnvironment','cpu');  %predictAndUpdateState函数是一次预测一个值并更新网络状态
            end
        % 验证神经网络
        YPred = sig*YPred + mu;      %使用先前计算的参数对预测去标准化。
        YPred = YPred';
        rmse(i) = sqrt(mean((YPred(1:num-numTrain)-dataValidation).^2)) ;     %计算均方根误差 (RMSE)。
        rmse_para(i,:)= Positions(i, :);
        % 更新 Alpha、Beta 和 Delta
        if rmse(i) < Alpha_score
            Alpha_score = rmse(i);
            Alpha_pos = Positions(i, :);
        end 
        if rmse(i) > Alpha_score && rmse(i) < Beta_score
            Beta_score = rmse(i);
            Beta_pos = Positions(i, :);
        end
        if rmse(i) > Alpha_score && rmse(i) > Beta_score && rmse(i) < Delta_score
            Delta_score = rmse(i);
            Delta_pos = Positions(i, :);
        end
    end
    % 线性递减
    a = 2 - l * 2 / Max_iter_GWO;  
    % 更新位置
    for i = 1 : SearchAgents_no
        for j = 1: dim
            %%%%% 更新策略
            r1 = rand();
            r2 = rand();
            A1 = 2*a*r1 - a;
            C1 = 2*r2;
            D_alpha = abs(C1*Alpha_pos(j) - Positions(i, j));
            X1 = Alpha_pos(j) - A1*D_alpha;

            r1 = rand();
            r2 = rand();            
            A2 = 2*a*r1 - a;
            C2 = 2*r2;
            D_beta = abs(C2*Beta_pos(j) - Positions(i, j));
            X2 = Beta_pos(j) - A2*D_beta;
            
            r1 = rand();
            r2 = rand();
            A3 = 2*a*r1 - a;
            C3 = 2*r2;
            D_delta = abs(C3*Delta_pos(j) - Positions(i, j));
            X3 = Delta_pos(j) - A3*D_delta;
            
            Positions(i, j) = round(((X1 + X2 + X3) / 3)/step(j))*step(j)+lb(j); %对更新项按照步长取整；
        end
    end
    Convergence_curve(l,:) = Alpha_score;
    Convergence_para(l,:) = Alpha_pos;
end
