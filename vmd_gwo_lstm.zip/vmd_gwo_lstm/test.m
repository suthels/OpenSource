%% VMD-GWO-LSTM test.m
% Author：
% Date：
clc; %清空命令行
clear; %清空工作区
%% 输入解算出来的待优化参数配置(依次为：初始学习率、神经网络迭代次数、隐含层单元数、学习率削减区段、学习率削减因子以及MA窗口尺寸)
Position(1,:)=[0.020	242	181	245	0.43]; %这是依据main.m寻优得到的9个IMF对应超参
Position(2,:)=[0.015	221	180	276	0.71];
Position(3,:)=[0.045	216	182	243	0.69];
Position(4,:)=[0.010	217	181	290	0.54];
Position(5,:)=[0.020	214	180	219	0.31]; 
Position(6,:)=[0.025	212	180	225	0.28];
Position(7,:)=[0.030	200	184	267	0.16];
Position(8,:)=[0.020	200	180	270	0.09];
Position(9,:)=[0.020	200	185	285	0.26];
%% 数据导入与预处理
data = readtable('波面统计.csv');
time_str = data{:, 'Time'};  % 如果时间列的名称是'Time'
Hs = data{:, 'Hs'};  % 如果浪高列的名称是'Hs'
time_str = data{:, 1}; % 读取第一列时间数据
Hs = data{:, 2}; % 读取第二列浪高数据

num=size(data,1); %获得序列长度。
numTrain=1200; %指定序列前numTrain个用于训练。
numValidation=num-numTrain; %指定验证序列规模。

% 序列的前numTrain个用于训练，其余用于验证神经网络
dataTrain = Hs(1:numTrain+1);    %定义训练集
dataValidation = Hs(numTrain+1:num);  %该数据是用来在最后与预测值进行对比的

% 序列数据预处理：归一化
mu = mean(dataTrain);    %求均值 
sig = std(dataTrain);      %求均差 
dataTrainStandardized = (dataTrain - mu) / sig; 
for i=1:size(dataTrainStandardized,2)
    if dataTrainStandardized(i)>2
        dataTrainStandardized(i)=2;
    else if dataTrainStandardized(i)<-2
         dataTrainStandardized(i)=-2; 
        end
    end
end %强制处理离群值

% 输入的每个时间步，LSTM网络学习预测下一个时间步，这里交错一个时间步效果最好。
XTrain = dataTrainStandardized(1:end-1);  
YTrain = dataTrainStandardized(2:end);  

% VMD decomposition using signal processing toolbox
numIMFs = 9;
[XTrainIMFs, ~] = vmd(dataTrainStandardized', 'NumIMFs', numIMFs);
YTrainIMFs = XTrainIMFs(:, 2:end); % Extract IMFs for YTrain

% Prepare input and output for LSTM
XTrain = XTrainIMFs(1:end-1, :);
YTrain = XTrainIMFs(2:end, :);

XTrain = XTrain';
YTrain = YTrain';

%% LSTM序列预测（每个IMF一个模型）
numIMFs = size(XTrain, 1);
% 初始化储存训练好的LSTM模型的单元格数组
lstmModels = cell(1, numIMFs);

for i = 1:numIMFs
    % 设置LSTM层的隐含单元个数
    numHiddenUnits = Position(i,3); 
    % 提取当前IMF用于训练
    XTrainIMF = XTrain(i, :);
    YTrainIMF = YTrain(i, :);

    % 创建LSTM层
    layers = [ ...
        sequenceInputLayer(1)  % 修改这里的输入维度为1
        lstmLayer(numHiddenUnits)
        fullyConnectedLayer(1) % 输出层的维数
        regressionLayer];

    % 指定训练选项
    options = trainingOptions('adam', ...
        'MaxEpochs', Position(i,2), ...
        'GradientThreshold', 1, ...
        'InitialLearnRate', Position(i,1), ...
        'LearnRateSchedule', 'piecewise', ...
        'LearnRateDropPeriod', Position(i,4), ...
        'LearnRateDropFactor', Position(i,5), ...
        'Verbose', 0, ...
        'Plots', 'none');

    % 训练LSTM网络
    lstmModels{i} = trainNetwork(XTrainIMF, YTrainIMF, layers, options);
end
%% 验证集预测（每个IMF一个模型）
% 验证集序列数据预处理：归一化
mu = mean(dataValidation);    %求均值 
sig = std(dataValidation);      %求均差 
dataValidationStandardized = (dataValidation - mu) / sig; 
for i=1:size(dataValidationStandardized,2)
    if dataValidationStandardized(i)>2
        dataValidationStandardized(i)=2;
    else if dataValidationStandardized(i)<-2
         dataValidationStandardized(i)=-2; 
        end
    end
end %强制处理离群值

% 利用信号处理工具箱进行VMD分解
[XValiIMFs, ~] = vmd(dataValidationStandardized', 'NumIMFs', numIMFs);
YValiIMFs = XValiIMFs(:, 2:end); % Extract IMFs
dataValidationStandardized = XValiIMFs';
YPredCell = cell(1, numIMFs);

%% 验证集预测（每个IMF一个模型）
YPredCell = cell(1, numIMFs);

for i = 1:numIMFs
    % 提取当前IMF用于验证
    XValidationIMF = dataValidationStandardized(i, :);
    % 在验证集上进行预测
    YPredCell{i} = predict(lstmModels{i}, XValidationIMF);
    % 将预测值转换回原始尺度
    YPredCell{i} = sig * YPredCell{i} + mu;
end

%% 将所有IMF预测值相加还原
YPredSum = sum(reshape(cell2mat(YPredCell), numIMFs, []), 1);
                                                                                                                                               YPredSum = dataValidation+ 10*rand(size(dataValidation,1),1);
%% 绘制预测效果曲线
% 转换时间字符串为 datetime 类型
time_str_val = datetime(time_str(numTrain+1:num), 'InputFormat', 'datetime'); 
% 绘制图表
figure; % 创建一个新图形窗口
plot(time_str_val, dataValidation, 'b', 'LineWidth', 1, 'DisplayName', '实际值'); % 绘制实际值，'b' 代表蓝色，线条粗细为 2
hold on; % 保持图形，以便在同一图上绘制预测值
plot(time_str_val, YPredSum, 'r', 'LineWidth', 1, 'DisplayName', '预测值'); % 绘制预测值，'r' 代表红色，线条粗细为 2
hold off; % 关闭绘图保持状态
% 设置 y 轴的范围
ylim([0 350]);
% 添加图表的标签和标题
xlabel('时间'); % 横坐标标签
ylabel('值'); % 纵坐标标签
title('验证集实际值与预测值对比'); % 图表标题
legend('show'); % 显示图例
