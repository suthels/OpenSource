%% VMDDecom.m
% Author：
% Date：
clc; %清空命令行
clear; %清空工作区
%% 数据导入与预处理
data = readtable('波面统计.csv');
time_str = data{:, 'Time'};  % 如果时间列的名称是'Time'
Hs = data{:, 'Hs'};  % 如果浪高列的名称是'Hs'
time_str = data{:, 1}; % 读取第一列时间数据
Hs = data{:, 2}; % 读取第二列浪高数据

% 用户设置参数
k_value = 9; % 用户设置的k值
PF = 3000; % 用户设置的惩罚因子

% VMD分解
numIMFs = k_value;
[HsIMFs, ~] = vmd(Hs,'NumIMF',numIMFs','PenaltyFactor',PF');

%% 绘制原始序列
figure;
plot(datetime(time_str), Hs, 'LineWidth', 1.5, 'Color', 'red');
title('原始序列');
xlabel('时间');
ylabel('浪高(m)');
grid on;

% 调整图形布局
set(gcf, 'Position', [100, 100, 800, 400]);

%% 绘制VMD分解后的每个HsIMF序列（九宫格构图）
figure;
for i = 1:numIMFs
    subplot(3, 3, i);
    plot(datetime(time_str), HsIMFs(:, i), 'LineWidth', 1.5);
    title(['HsIMF ' num2str(i)]);
    xlabel('时间');
    ylabel('IMF值(m)');
    grid on;
end

% 调整图形布局
set(gcf, 'Position', [100, 100, 800, 800]);
sgtitle('VMD分解后的HsIMF序列');