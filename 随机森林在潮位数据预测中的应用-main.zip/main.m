%% 随机森林时间序列预测实现
% 读取Excel数据
filename = 'data_tp.xlsx';
data = xlsread(filename);

% 提取特征和标签
X = data(:, 1:3); % 年、月、日作为特征
y = data(:, 4);   % 潮位数据作为标签

% 分割数据集为训练集和测试集（这里简单地将前70%的数据作为训练集，后30%的数据作为测试集）
split_ratio = 0.7;
split_idx = round(split_ratio * size(X, 1));
X_train = X(1:split_idx, :);
y_train = y(1:split_idx);
X_test = X(split_idx+1:end, :);
y_test = y(split_idx+1:end);

% 使用随机森林进行序列预测
rf_model = TreeBagger(30, X_train, y_train); % 使用50棵决策树
min_leaf_size = 5; % 叶子节点的最小样本数

% 训练集预测
y_train_pred = predict(rf_model, X_train);

% 测试集预测
y_test_pred = predict(rf_model, X_test);

% 计算训练集和测试集的预测误差
train_rmse = sqrt(mean((str2double(y_train_pred) - y_train).^2));
test_rmse = sqrt(mean((str2double(y_test_pred) - y_test).^2));

% 绘制训练集预测结果对比图
figure;
plot(y_train, 'b', 'LineWidth', 1.5);
hold on;
plot(str2double(y_train_pred), 'r--', 'LineWidth', 1);
xlabel('样本索引');
ylabel('潮位数据');
legend('真实值', '预测值');
title('训练集预测结果对比');
grid on;

% 绘制测试集预测结果对比图
figure;
plot(y_test, 'b', 'LineWidth', 1.5);
hold on;
plot(str2double(y_test_pred), 'r--', 'LineWidth', 1);
xlabel('样本索引');
ylabel('潮位数据');
legend('真实值', '预测值');
title('测试集预测结果对比');
grid on;

% 绘制误差评估指标对比图
figure;
bar([train_rmse, test_rmse]);
xlabel('数据集');
ylabel('RMSE值');
xticklabels({'训练集', '测试集'});
title('训练集和测试集的RMSE对比');
grid on;

% 计算训练集上的各种评估指标
train_rmse = sqrt(mean((str2double(y_train_pred) - y_train).^2));
train_mae = mean(abs(str2double(y_train_pred) - y_train));
train_mse = mean((str2double(y_train_pred) - y_train).^2);
train_r2 = 1 - sum((str2double(y_train_pred) - y_train).^2) / sum((y_train - mean(y_train)).^2);

% 计算测试集上的各种评估指标
test_rmse = sqrt(mean((str2double(y_test_pred) - y_test).^2));
test_mae = mean(abs(str2double(y_test_pred) - y_test));
test_mse = mean((str2double(y_test_pred) - y_test).^2);
test_r2 = 1 - sum((str2double(y_test_pred) - y_test).^2) / sum((y_test - mean(y_test)).^2);

% 输出各种评估指标的结果
fprintf('训练集评估指标：\n');
fprintf('RMSE: %.4f\n', train_rmse);
fprintf('MAE: %.4f\n', train_mae);
fprintf('MSE: %.4f\n', train_mse);
fprintf('R^2: %.4f\n', train_r2);
fprintf('\n');
fprintf('测试集评估指标：\n');
fprintf('RMSE: %.4f\n', test_rmse);
fprintf('MAE: %.4f\n', test_mae);
fprintf('MSE: %.4f\n', test_mse);
fprintf('R^2: %.4f\n', test_r2);

% 绘制训练集和测试集的预测结果对比图
figure;
subplot(2, 1, 1);
plot(y_train, 'b', 'LineWidth', 1.5);
hold on;
plot(str2double(y_train_pred), 'r--', 'LineWidth', 1.5);
xlabel('样本索引');
ylabel('潮位数据');
legend('真实值', '预测值');
title('训练集预测结果对比');
grid on;

subplot(2, 1, 2);
plot(y_test, 'b', 'LineWidth', 1.5);
hold on;
plot(str2double(y_test_pred), 'r--', 'LineWidth', 1.5);
xlabel('样本索引');
ylabel('潮位数据');
legend('真实值', '预测值');
title('测试集预测结果对比');
grid on;

% 绘制各种评估指标的对比图
figure;
bar([train_rmse, test_rmse; train_mae, test_mae; train_mse, test_mse; train_r2, test_r2]);
xlabel('评估指标');
ylabel('值');
xticklabels({'RMSE', 'MAE', 'MSE', 'R^2'});
legend('训练集', '测试集');
title('各种评估指标对比');
grid on;

