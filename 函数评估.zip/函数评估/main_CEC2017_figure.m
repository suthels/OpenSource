clc
clear all
close all

%% ������ʼ������
algorithms = {'GWO','LPO'};
nPop = 100;                  %��Ⱥ��
Max_iter = 10000;             %����������
dim = 10;                   %��ѡ 10��30��50��100
maxFES = Max_iter.*nPop;

for j = 1:5
    %% ѡ����
    Function_name = j; % �������� 1 - 30
    [lb, ub, dim, fobj] = Get_CEC2017_details(Function_name,dim);

           %% GWO�㷨�������㷨��
    tic
    [GWO_Best_score, GWO_Best_pos, GWO_cg_curve] = GWO(nPop, maxFES, lb, ub, dim, fobj);
    toc
    display(['The best optimal value of the objective function found by GWO for F' num2str(Function_name), ' is: ', num2str(GWO_Best_score)]);
    fprintf('Best solution obtained by GWO: %s\n', num2str(GWO_Best_pos, '%e  '));

    %% LPO�㷨�������㷨��
    tic
    [LPO_Best_score, LPO_Best_pos, LPO_cg_curve] = LPO(nPop, maxFES, lb, ub, dim, fobj);
    toc
    display(['The best optimal value of the objective function found by LPO for F' num2str(Function_name), ' is: ', num2str(LPO_Best_score)]);
    fprintf('Best solution obtained by LPO: %s\n', num2str(LPO_Best_pos, '%e  '));
    

    %% plot��ͼ
    figure;
    colors = lines(length(algorithms));
    for i = 1:length(algorithms)
        semilogy(eval([algorithms{i} '_cg_curve']), 'Color', colors(i, :), 'Linewidth', 1);
        hold on
    end
    title(['Convergence curve, dim=' num2str(dim)])
    xlabel('Iteration')
    ylabel(['Best score F' num2str(Function_name)])
    axis tight
    grid on
    box on
    set(gca, 'color', 'none')
    % Add legend
    legend(algorithms, 'Location', 'Best');
end