
% 调用函数生成并展示 tent 映射的图像

function tle = Map_name(label)
    if label==1
            % tent 映射
            tle = 'tent';
    elseif label==2
            %chebyshev 映射
            tle = 'chebyshev';
    elseif label==3
            %singer 映射
            tle = 'singer';
    elseif label==4
            %Logistic 映射
            tle = 'Logistic'; 
    elseif label==5
            %Sine 映射
            tle = 'Sine';
    elseif label==6
            % Circle 映射
            tle = 'Circle';
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    elseif label==7
           % Gauss/mouse 混沌映射 
           tle = 'Gauss/mouse';
    elseif label==8
           % Iterative 混沌映射
           tle = 'Iterative';
    elseif label==9
           % Piecewise 混沌映射
           tle = 'Piecewise';
    elseif label==10
           % Sinusoidal 混沌映射
           tle = 'Sinusoidal';
    elseif label==11
           % Fuch 混沌映射
           tle = 'Fuch';
    elseif label==12
           % SPM 混沌映射
           tle = 'SPM';
    elseif label==13
           % ICMIC 混沌映射
           tle = 'ICMIC';
    elseif label==14
           % Tent-Logistic-Cosine混沌映射
           tle = 'Tent-Logistic-Cosine';
    elseif label==15
           % Sine-Tent-Cosine混沌映射
           tle = 'Sine-Tent-Cosine';
    elseif label==16
           % Logistic-Sine-Cosine混沌映射
           tle = 'Logistic-Sine-Cosine';
    elseif label==17
           % Henon混沌映射
           tle = 'Henon';
    elseif label==18
           % Cubic混沌映射
           tle = 'Cubic';
    elseif label==19
           % Logistic-Tent 混沌映射
           tle = 'Logistic-Tent';
    elseif label==20
           % Bernoulli 混沌映射
           tle = 'Bernoulli';
    elseif label==21
           % Kent 混沌映射
           tle = 'Kent';
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    else
        %无映射
       tle = '无映射';
    end
end
