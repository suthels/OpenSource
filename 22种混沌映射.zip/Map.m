%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 混沌映射类型选择，label的1-6分别为tent、chebyshev
% tent、chebyshev、Singer、Logistic、Sine, Circle
% 调用函数生成并展示 tent 映射的图像

function result = Map( N, dim,label)
    if label==1
            % tent 映射
            tent=0.55;  %tent混沌系数
            Tent = rand(N, dim);
            for i=1:N
                for j=2:dim
                    if Tent(i,j-1)<tent
                        Tent(i,j)=Tent(i,j-1)/tent;
                    elseif Tent(i,j-1)>=tent
                        Tent(i,j)=(1-Tent(i,j-1))/(1-tent);
                    end
                end
            end
            result = Tent;
    elseif label==2
            %chebyshev 映射
            chebyshev=5;
            Chebyshev=rand(N,dim);
            for i=1:N
                for j=2:dim
                    Chebyshev(i,j)=cos(chebyshev.*acos(Chebyshev(i,j-1)));
                end
            end
            result = Chebyshev;
    elseif label==3
            %singer 映射
            u=1.06;
            singer=rand(N,dim);
              for i=1:N
                for j=2:dim
            singer(i,j)=u*(7.86*singer(i,j-1)-23.31*singer(i,j-1).^2+28.75*singer(i,j-1).^3-13.302875*singer(i,j-1).^4);
                end
              end
              result = singer; 
    elseif label==4
            %Logistic 映射
            miu=4;  %混沌系数
            Logistic=rand(N,dim);
            for i=1:N
                for j=2:dim
                    Logistic(i,j)=miu.* Logistic(i,j-1).*(1-Logistic(i,j-1));
                end
            end
            result = Logistic;  
    elseif label==5
            %Sine 映射
            sine=4;
            Sine=rand(N,dim);
            for i=1:N
                for j=2:dim
                    Sine(i,j)=(4/sine)*sin(pi*Sine(i,j-1));
                end
            end
            result = Sine;
    elseif label==6
    
            % Circle 映射
            a = 0.5; b=2.2;
            Circle=rand(N,dim);
            for i=1:N
                for j=2:dim
                    Circle(i,j)=mod(Circle(i,j-1)+a-b/(2*pi)*sin(2*pi*Circle(i,j-1)),1);
                end
            end
            result = Circle;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    elseif label==7
           % Gauss/mouse 混沌映射 
           Gauss = rand(N, dim);
           a=1;
           for i=1:N
               for j=2:dim
                   if (Gauss(i,j-1)==0)
                       Gauss(i,j)=0;
                   elseif Gauss(i,j-1)~=0
    %                    Gauss(i,j)=a/mod(Gauss(i,j-1),1);
                       Gauss(i,j)=(rem(a/Gauss(i,j-1),1)) ;
                       %Gauss(i,j)=mod(a * Gauss(i,j-1) * (1 - Gauss(i,j-1)), 1);
                   end
               end
           end
           result = Gauss;
    elseif label==8
           % Iterative 混沌映射
           iterative = 0.7;
           Iterative = rand(N, dim);
           for i=1:N
               for j=2:dim
                   Iterative(i,j)=sin((iterative * pi)/ Iterative(i,j-1));
               end
           end
           result = Iterative;
    elseif label==9
           % Piecewise 混沌映射
           P = 0.1;
           Piecewise = rand(N, dim);
           for i=1:N
               for j=2:dim
                   if (Piecewise(i,j-1)<P) && (( Piecewise(i,j-1)>=0))
                       Piecewise(i,j)=Piecewise(i,j-1)/P;
                   elseif (Piecewise(i,j-1)<0.5) && (( Piecewise(i,j-1)>=P))
                       Piecewise(i,j)=(Piecewise(i,j-1)-P)/(0.5-P);
                   elseif (Piecewise(i,j-1)<(1-P)) && (( Piecewise(i,j-1)>=0.5))
                       Piecewise(i,j)=(1 - P - Piecewise(i,j-1))/(0.5-P);
                   elseif (Piecewise(i,j-1)<1) && (( Piecewise(i,j-1)>=(1-P)))
                       Piecewise(i,j)=(1- Piecewise(i,j-1))/P;
                   end
               end
           end
           result = Piecewise;
    elseif label==10
           % Sinusoidal 混沌映射
           a = 2.3;
           Sinusoidal = zeros(N, dim);
           Sinusoidal(:,1)= 0.74;   
           for i=1:N
               for j=2:dim
                   Sinusoidal(i,j)=a * Sinusoidal(i,j-1)^2 * sin(pi*Sinusoidal(i,j-1));
               end
           end
           result = Sinusoidal;
    elseif label==11
           % Fuch 混沌映射
           Fuch = rand(N, dim);
           for i=1:N
               for j=2:dim
                   Fuch(i,j)=cos(1/Fuch(i,j-1).^2);
               end
           end
           result = Fuch;
    elseif label==12
           % SPM 混沌映射
           a = 0.4; %η
           b = 0.3; %μ
           r = rand;
           SPM = rand(N, dim);
           for i=1:N
               for j=2:dim
                   if (SPM(i,j-1)<a) && (( SPM(i,j-1)>=0))
                       SPM(i,j)=mod(((SPM(i,j-1)/a)+(b * sin(pi*SPM(i,j-1)))+r),1);
                   elseif (SPM(i,j-1)<0.5) && (( SPM(i,j-1)>=a))
                       SPM(i,j)=mod((((SPM(i,j-1)/a)/(0.5-a))+(b * sin(pi*SPM(i,j-1)))+r),1);
                   elseif (SPM(i,j-1)<(1-a)) && (( SPM(i,j-1)>=0.5))
                       SPM(i,j)=mod((((1-SPM(i,j-1)/a)/(0.5-a))+(b * sin(pi*(1-SPM(i,j-1))))+r),1);
                   elseif (SPM(i,j-1)<1) && (( SPM(i,j-1)>=(1-a)))
                       SPM(i,j)=mod((((1-SPM(i,j-1)/a)/a)+(b * sin(pi*(1-SPM(i,j-1))))+r),1);
                   end
               end
           end
           result = SPM;
    elseif label==13
           % ICMIC 混沌映射
           a = 10;
           ICMIC = rand(N, dim);
           for i=1:N
               for j=2:dim
                   ICMIC(i,j)=sin(a/ICMIC(i,j-1));
               end
           end
           result = ICMIC;
    elseif label==14
           % Tent-Logistic-Cosine混沌映射
           r=0.6;
           TLC = rand(N, dim);
           for i=1:N
               for j=2:dim
                   if TLC(i, j-1) < 0.5
                       TLC(i,j)=cos(pi*(2 * r *TLC(i,j-1)+ 4*(1-r)*TLC(i,j-1)*(1-TLC(i,j-1)-0.5))); 
                   else
                       TLC(i,j)=cos(pi*(2 * r *(1-TLC(i,j-1))+ 4*(1-r)*TLC(i,j-1)*(1-TLC(i,j-1)-0.5))); 
                   end
               end
           end
           result = TLC;
    elseif label==15
           % Sine-Tent-Cosine混沌映射
           r = rand;
           STC = rand(N, dim);
           for i=1:N
               for j=2:dim
                   if STC(i, j-1) < 0.5
                       STC(i,j)=cos(pi*(r *sin(pi*STC(i,j-1))+ 2*(1-r)*STC(i,j-1)-0.5)); 
                   else
                       STC(i,j)=cos(pi*(r *sin(pi*STC(i,j-1))+ 2*(1-r)*(1-STC(i,j-1))-0.5));  
                   end
               end
           end
           result = STC;
    elseif label==16
           % Logistic-Sine-Cosine混沌映射
           r = 0.5;
           LSC = rand(N, dim);
           for i=1:N
               for j=2:dim
                   LSC(i,j)=cos(pi*(4*r*LSC(i,j-1)*(1-LSC(i,j-1))+(1-r)*sin(pi*LSC(i,j-1)-0.5)));
               end
           end
           result = LSC;
    elseif label==17
           % Henon混沌映射
           a=1.4;
           b=0.3;
           Henon = zeros(N, dim);
           Henon_y = zeros(N, dim);
           Henon(:,1)= 0.15; 
           Henon_y(:,1)= 0.15; 
           for i=1:N
               for j=2:dim
                   if j >=2
                      Henon(i, j) = 1 - a * Henon(i, j-1).^2 + Henon_y(i, j-1);
                      Henon_y(i, j) = b * Henon(i, j-1);
                   end
               end
           end
           result = Henon;
    elseif label==18
           % Cubic混沌映射
           a = 2.595;
           Cubic = rand(N, dim);
           for i=1:N
               for j=2:dim
                   Cubic(i,j)=a * Cubic(i,j-1) * (1-Cubic(i,j-1).^2);
               end
           end
           result = Cubic;
    elseif label==19
           % Logistic-Tent 混沌映射
           r = rand;
           while r == 0 || r == 1
                 r = rand;
           end
           r = 4 * r;
           LT = rand(N, dim);
           for i=1:N
               for j=2:dim
                   if LT(i, j-1)<0.5
                      LT(i,j)=mod(r*LT(i,j-1)*(1-LT(i,j-1))+(4-r)*LT(i, j-1)/2,1);
                   else 
                      LT(i,j)=mod(r*LT(i,j-1)*(1-LT(i, j-1))+(4-r)*(1-LT(i, j-1))/2,1);
                   end
               end
           end
           result = LT;
    elseif label==20
           % Bernoulli 混沌映射
           a = 0.4; 
           Bernoulli = rand(N, dim);
           for i=1:N
               for j=2:dim
                   if (Bernoulli(i,j-1)<=(1-a)) && (( Bernoulli(i,j-1)>0))
                       Bernoulli(i,j)= Bernoulli(i,j-1)/(1-a);
                   elseif (Bernoulli(i,j-1)<=1) && (( Bernoulli(i,j-1)>(1-a)))
                       Bernoulli(i,j)=(Bernoulli(i,j-1)-1+a)/a;
                   end
               end
           end
           result = Bernoulli;
    elseif label==21
           % Kent 混沌映射
           a = 0.5; 
           Kent = rand(N, dim);
           for i=1:N
               for j=2:dim
                   if (Kent(i,j-1)<=a) && (( Kent(i,j-1)>0))
                       Kent(i,j)= Kent(i,j-1)/a;
                   elseif (Kent(i,j-1)<1) && (( Kent(i,j-1)>a))
                       Kent(i,j)=(1 - Kent(i,j-1))/(1-a);
                   end
               end
           end
           result = Kent;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    else
        %无映射
       result =rand(N,dim);
    end

    
end